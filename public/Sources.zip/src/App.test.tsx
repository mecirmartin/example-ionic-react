import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import { render } from '@testing-library/react'

// it('renders without crashing', () => {
//   // const div = document.createElement('div');
//   // ReactDOM.render(<App />, div);
//   // ReactDOM.unmountComponentAtNode(div);
//     const locale = navigator.language;
//     loadLocaleData(locale).then((messages) => {    
//       const { asFragment } = render(<App locale={locale}  messages={messages} />);
//       // expect(asFragment()).toMatchSnapshot();

//   });
// });

